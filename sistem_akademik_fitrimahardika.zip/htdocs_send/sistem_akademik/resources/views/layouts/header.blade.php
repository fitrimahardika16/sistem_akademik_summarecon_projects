<!DOCTYPE html>
<html lang="en">
    <head>
          <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

         <!-- Required meta tags -->

       {{-- Laravel Mix - CSS File --}}

               <!-- Bootstrap Core CSS -->
        <link href="css_one/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css_one/metisMenu.min.css" rel="stylesheet">

        <!-- Timeline CSS -->
        <link href="css_one/timeline.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css_one/startmin.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="css_one/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css_one/font-awesome.min.css" rel="stylesheet" type="text/css">

            <link href="/css_one/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="/css_one/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="/css_one/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="/css_one/font-awesome.min.css" rel="stylesheet" type="text/css">

         <!-- jQuery -->
    <body>
        @yield('content')

        {{-- Laravel Mix - JS File --}}
        {{-- <script src="{{ mix('js/dashboard.js') }}"></script> --}}

                <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Morris Charts JavaScript -->
        <script src="js/raphael.min.js"></script>
        <script src="js/morris.min.js"></script>
        <script src="js/morris-data.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>
    </head>
    </body>
</html>
