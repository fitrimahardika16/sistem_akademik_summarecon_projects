@extends('layouts.header')

@section('content')
 <div id="wrapper">

            <!-- Navigation -->
               @include('layouts.page')
             <!-- Navigation -->
        <div id="page-wrapper">
           <div class="container-fluid">
                <div class="row">
                   <div class="col-lg-12">
                        <h1 class="page-header">Mata Kuliah</h1>
                    </div>
                      <a class="btn btn-primary" href="/tambah_mata_kuliah" role="button">Tambah Mata Kuliah</a>
                </div>
                <br>
                    <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Mata Kuliah
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                   <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                               <th>Kode Mata Kuliah</th>
                                                <th>Nama Mata Kuliah</th>
                                                <th>SKS</th>
                                                <!-- <th> Tanggal </th>
                                                <th>Jam Masuk</th>
                                                <th>Jam Keluar</th> -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($data as $data_kuliah)
                                            <tr class="odd gradeX">
                                                <td>{{ $data_kuliah->kode_matakuliah }}</td>
                                                <td>{{ $data_kuliah->nama_matakuliah }}</td>
                                              <td>{{ $data_kuliah->sks }}</td>
                                              <!-- <td>{{ $data_kuliah->tanggal }} </td>
                                              <td>{{ $data_kuliah->jam_masuk }}</td>
                                              <td>{{ $data_kuliah->jam_keluar }}</td> -->
                                              <td>
                                              <a href="/edit_matakuliah/{{ $data_kuliah->id_matakuliah }}">Edit</a>|<a href="/delete_matakuliah/{{ $data_kuliah->id_matakuliah }}">Hapus</a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                  <!--   <nav aria-label="...">
                                      <ul class="pagination">
                                        <li class="page-item disabled">
                                          <span class="page-link">Previous</span>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item active">
                                          <span class="page-link">
                                            2
                                            <span class="sr-only">(current)</span>
                                          </span>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item">
                                          <a class="page-link" href="#">Next</a>
                                        </li>
                                      </ul>
                                    </nav> -->
                                </div>
                                    <!-- /.table-responsive -->
                            </div>
                                <!-- /.panel-body -->
                        </div>
                            <!-- /.panel -->
                    </div>
                        <!-- /.col-lg-12 -->
                </div>
            </div>
                <!-- /.container-fluid -->
        </div>
            <!-- /#page-wrapper -->
    </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        DataTables JavaScript
        <script src="../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../js/dataTables/dataTables.bootstrap.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>

@endsection
