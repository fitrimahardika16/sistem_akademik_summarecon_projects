@extends('layouts.header')

@section('content')
 <div id="wrapper">

            <!-- Navigation -->
               @include('layouts.page')
             <!-- Navigation -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Forms Tambah Data Jadwal Kuliah</h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Forms Tambah Data Jadwal Kuliah
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <form role="form" action="/saveJadwal" method="post">
                                            	{{ csrf_field() }}
                                                <div class="form-group">
                                                    <label>Nama Mahasiswa</label>
                                                   <select class="form-control" name="nim_mahasiswa">

                                                @foreach ($data_mahasiswa as $value)

                                                    <option value="{{ $value->nim_mahasiswa }}"> 

                                                        {{ $value->nama_mahasiswa }} 

                                                    </option>

                                                @endforeach    

                                            </select>
                                                </div>
                                                 <div class="form-group">
                                                     <label>Nama Dosen</label>
                                                    <select class="form-control" name="id_dosen">

                                                @foreach ($data_dosen as $value)

                                                    <option value="{{ $value->id_dosen }}"> 

                                                        {{ $value->nama_dosen }} 

                                                    </option>

                                                @endforeach    

                                            </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mata Kuliah</label>
                                                    <select class="form-control" name="kode_matakuliah">

                                                @foreach ($data_matakuliah as $value)

                                                    <option value="{{ $value->kode_matakuliah }}"> 

                                                        {{ $value->nama_matakuliah }} 

                                                    </option>

                                                @endforeach    

                                            </select>
                                                </div>
                                              <div class="form-group">
                                                    <label>Tanggal Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="date" name="tanggal">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Masuk</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="time" name="jam_masuk">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Keluar</label>
                                                    <input class="form-control" placeholder="time"
                                                     type="time" name="jam_keluar">
                                                </div>
                                                <button type="submit" class="btn btn-default">Submit Button</button>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>

  </div>

@endsection
