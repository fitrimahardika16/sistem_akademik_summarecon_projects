<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class data_mahasiswa extends Model
{
    use HasFactory;
   	protected $table = 'data_mahasiswa';
    protected $primaryKey = 'id_mahasiswa';
    //public $incrementing = false;
    //protected $keyType = 'string';
    public $timestamps = false;
}
