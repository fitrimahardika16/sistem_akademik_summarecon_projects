<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class data_mata_kuliah extends Model
{
    use HasFactory;
   	protected $table = 'data_mata_kuliah';
    protected $primaryKey = 'id_matakuliah';
    //public $incrementing = false;
    //protected $keyType = 'string';
    public $timestamps = false;
}
