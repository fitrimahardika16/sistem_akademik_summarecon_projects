<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\data_mahasiswa;

class mahasiswa_controller extends Controller
{
    
    public function index_mahasiswa()
    {
    	 $data = data_mahasiswa::all();
    
          return view('data_mahasiswa', [
            'data' => $data
        ]);
 
    }

    public function tambah_mahasiswa()
    {
    	return view('tambah_mahasiswa');
    }

    public function savemahasiswa(Request $request)
	{
	
		DB::table('data_mahasiswa')->insert([
			'nim_mahasiswa' => $request->nim_mahasiswa,
			'nama_mahasiswa' => $request->nama_mahasiswa,
			'alamat_mahasiswa' =>$request->alamat_mahasiswa,
			'jenis_kealmi' => isset($request->jenis_kealmi) ? $request->jenis_kealmi:'', 
			'image' => isset($request->image) ? $request->image:'', 
		]);

		return redirect('/datamahasiswa');
	}

	public function delete_mahasiswa($id)
	{
		DB::table('data_mahasiswa')->where('id_mahasiswa', $id)->delete();

		return redirect('/datamahasiswa');
	}

	public function edit_mahasiswa($id)
	{
		$data_dosen = DB::table('data_mahasiswa')->where('id_mahasiswa', $id)->get();

		return view('edit_mahasiswa',['data' => $data_dosen]);
	}

	public function update_mahasiswa(Request $request)
	{
		DB::table('data_mahasiswa')->where('id_mahasiswa',$request->id)->update([
			'nim_mahasiswa' => $request->nim_mahasiswa,
			'nama_mahasiswa' => $request->nama_mahasiswa,
			'alamat_mahasiswa' => $request->alamat_mahasiswa,
			'jenis_kealmi' => isset($request->jenis_kealmi) ? $request->jenis_kealmi:'', 
			'image' => isset($request->image) ? $request->image:'', 
		]);
		// alihkan halaman ke halaman
		return redirect('/datamahasiswa');
	}
}
