<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\data_dosen;
use Illuminate\Support\Facades\DB;
use App\Models\data_mata_kuliah;

class dosen_controller extends Controller
{
    	 public function index_dosen()
    {
    	 $data =DB::table('data_dosen')

            ->leftJoin('data_mata_kuliah', 'data_dosen.id_matakuliah', '=', 'data_mata_kuliah.kode_matakuliah')
      

            ->get();

          return view('data_dosen', [
            'data' => $data
        ]);
 
    }


    public function tambah_dosen()
    {	
    	$data_matakuliah = data_mata_kuliah::all();

    	 return view('tambah_dosen', [
            'data' => $data_matakuliah
        ]);
 
    }

    public function savedosen(Request $request)
	{
	
		DB::table('data_dosen')->insert([
			'nama_dosen' => $request->nama_dosen,
			'alamat_dosen' => $request->alamat_dosen,
			'id_matakuliah' => isset($request->id_matakuliah) ? $request->id_matakuliah: 0, 
			'image' => isset($request->image) ? $request->image:'', 
		]);

		return redirect('/datadosen');
	}

	public function delete_dosen($id)
	{
		DB::table('data_dosen')->where('id_dosen', $id)->delete();

		return redirect('/datadosen');
	}

	public function edit_dosen($id)
	{
		$data_dosen = DB::table('data_dosen')->where('id_dosen', $id)->get();

		return view('edit_dosen',['data' => $data_dosen]);
	}

	public function update_datadosen(Request $request)
	{
		DB::table('data_dosen')->where('id_dosen',$request->id)->update([
			'nama_dosen' => $request->nama_dosen,
			'alamat_dosen' => $request->alamat_dosen,
			'id_matakuliah' => isset($request->id_matakuliah) ? $request->id_matakuliah:'', 
			'image' => isset($request->image) ? $request->image:'', 
		]);
		// alihkan halaman ke halaman
		return redirect('/datadosen');
	}
}
