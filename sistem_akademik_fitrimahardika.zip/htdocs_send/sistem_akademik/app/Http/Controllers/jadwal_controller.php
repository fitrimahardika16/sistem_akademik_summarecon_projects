<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\data_mahasiswa;
use App\Models\data_mata_kuliah;
use App\Models\data_dosen;

class jadwal_controller extends Controller
{
    public function index()
    {
    	    $jadwal =DB::table('data_jadwal')

            ->leftJoin('data_dosen', 'data_jadwal.id_dosen', '=', 'data_dosen.id_dosen')
            ->leftJoin('data_mahasiswa', 'data_jadwal.nim_mahasiswa', '=', 'data_mahasiswa.nim_mahasiswa')
            ->leftJoin('data_mata_kuliah', 'data_jadwal.kode_matakuliah', '=', 'data_mata_kuliah.kode_matakuliah')

            ->get();


  			return view('index',['data' => $jadwal]);
 
    }

    public function tambahjadwal ()
    {	
    	$data_mahasiswa = data_mahasiswa::all();
    	$data_dosen = data_dosen::all();
    	$data_matakuliah = data_mata_kuliah::all();

    	 return view('tambah_jadwal', [
            'data_matakuliah' => $data_matakuliah,
            'data_dosen' => $data_dosen,
            'data_mahasiswa' => $data_mahasiswa
        ]);
 
    }

     public function save_jadwal(Request $request)
	{
	
		DB::table('data_jadwal')->insert([
			'nim_mahasiswa' => $request->nim_mahasiswa,
			'kode_matakuliah' => $request->kode_matakuliah,
			'id_dosen' => $request->id_dosen,
			'tanggal' => $request->tanggal,
			'jam_masuk' => $request->jam_masuk,
			'jam_keluar' => $request->jam_keluar
		]);

		return redirect('/');
	}

}
