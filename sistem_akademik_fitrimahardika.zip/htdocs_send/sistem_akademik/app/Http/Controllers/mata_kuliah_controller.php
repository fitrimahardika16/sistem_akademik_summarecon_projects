<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\data_mata_kuliah;

class mata_kuliah_controller extends Controller
{

	 public function index_matakuliah()
    {
    	 $data = data_mata_kuliah::all();
    
          return view('data_matakuliah', [
            'data' => $data
        ]);
 
    }

    public function tambah_mata_kuliah()
    {
    	return view('tambah_mata_kuliah');
    }

    public function savematakuliah(Request $request)
	{
	
		DB::table('data_mata_kuliah')->insert([
			'kode_matakuliah' => $request->kode_matakuliah,
			'nama_matakuliah' => $request->nama_matakuliah,
			'sks' => $request->sks,
			// 'tanggal' => $request->tanggal,
			// 'jam_masuk' => $request->jam_masuk,
			// 'jam_keluar' => $request->jam_keluar
		]);

		return redirect('/matakuliah');
	}

	public function delete_matakuliah($id)
	{
		DB::table('data_mata_kuliah')->where('id_matakuliah', $id)->delete();

		return redirect('/matakuliah');
	}

	public function edit_matakuliah($id)
	{
		$data_mata_kuliah = DB::table('data_mata_kuliah')->where('id_matakuliah', $id)->get();

		return view('edit_mata_kuliah',['data' => $data_mata_kuliah]);
	}

	public function update_matakuliah(Request $request)
	{
		DB::table('data_mata_kuliah')->where('id_matakuliah',$request->id)->update([
			'kode_matakuliah' => $request->kode_matakuliah,
			'nama_matakuliah' => $request->nama_matakuliah,
			'sks' => $request->sks,
			// 'tanggal' => $request->tanggal,
			// 'jam_masuk' => $request->jam_masuk,
			// 'jam_keluar' => $request->jam_keluar
		]);
		// alihkan halaman ke halaman mata kuliah
		return redirect('/matakuliah');
	}

}
