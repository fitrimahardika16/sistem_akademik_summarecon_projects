<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class DataDosen extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('data_dosen', function (Blueprint $table) {
            $table->bigIncrements('id_dosen');
            $table->char('nama_dosen');
            $table->text('alamat_dosen');
            $table->string('image');
            $table->tinyinteger('id_matakuliah');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_dosen');
    }
}
