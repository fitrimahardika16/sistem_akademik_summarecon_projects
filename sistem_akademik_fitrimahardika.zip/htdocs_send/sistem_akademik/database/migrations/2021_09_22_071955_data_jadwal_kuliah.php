<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class DataJadwalKuliah extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('data_jadwal', function (Blueprint $table) {
            $table->bigIncrements('id_jadwal');
            $table->integer('nim_mahasiswa');
            $table->integer('kode_matakuliah');
            $table->integer('id_dosen');
            $table->date('tanggal');
            $table->time('jam_masuk');
            $table->time('jam_keluar');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_jadwal');
    }
}
