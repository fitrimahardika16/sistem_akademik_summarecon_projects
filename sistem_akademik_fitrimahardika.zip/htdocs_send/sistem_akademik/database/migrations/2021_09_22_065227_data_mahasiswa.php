<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class DataMahasiswa extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('data_mahasiswa', function (Blueprint $table) {
            $table->bigIncrements('id_mahasiswa');
            $table->integer('nim_mahasiswa');
            $table->char('nama_mahasiswa');
            $table->boolean('jenis_kealmi');
            $table->text('alamat_mahasiswa');
            $table->string('image');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_mahasiswa');
    }
}
