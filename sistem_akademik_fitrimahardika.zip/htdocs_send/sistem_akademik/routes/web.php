<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Dosen_Controller;
use App\Http\Controllers\Mahasiswa_Controller;
use App\Http\Controllers\Mata_Kuliah_Controller;
use App\Http\Controllers\Jadwal_Controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
# Jadwal Kuliah
Route::get('/', [Jadwal_Controller::class, 'index']);
Route::get('/tambah_jadwal', [Jadwal_Controller::class, 'tambahjadwal']); 
Route::post('/saveJadwal', [Jadwal_Controller::class, 'save_jadwal']);
# Mata Kuliah

Route::get('/matakuliah', [Mata_Kuliah_Controller::class, 'index_matakuliah']);
Route::get('/tambah_mata_kuliah',[Mata_Kuliah_Controller::class, 'tambah_mata_kuliah']);
Route::post('/savematakuliah', [Mata_Kuliah_Controller::class, 'savematakuliah']);
Route::get('/delete_matakuliah/{id}', [Mata_Kuliah_Controller::class, 'delete_matakuliah']);
Route::get('/edit_matakuliah/{id}', [Mata_Kuliah_Controller::class, 'edit_matakuliah']);
Route::post('/update_matakuliah', [Mata_Kuliah_Controller::class, 'update_matakuliah']);


# Mahasiswa
Route::get('/datamahasiswa', [Mahasiswa_Controller::class, 'index_mahasiswa']);
Route::get('/tambah_mahasiswa',[Mahasiswa_Controller::class, 'tambah_mahasiswa']);
Route::post('/savemahasiswa', [Mahasiswa_Controller::class, 'savemahasiswa']);
Route::get('/delete_mahasiswa/{id}', [Mahasiswa_Controller::class, 'delete_mahasiswa']);
Route::get('/edit_mahasiswa/{id}', [Mahasiswa_Controller::class, 'edit_mahasiswa']);
Route::post('/update_mahasiswa', [Mahasiswa_Controller::class, 'update_mahasiswa']);


# Dosen
Route::get('/datadosen', [Dosen_Controller::class, 'index_dosen']);
Route::get('/tambah_dosen',[Dosen_Controller::class, 'tambah_dosen']);
Route::post('/savedosen', [Dosen_Controller::class, 'savedosen']);
Route::get('/delete_dosen/{id}', [Dosen_Controller::class, 'delete_dosen']);
Route::get('/edit_dosen/{id}', [Dosen_Controller::class, 'edit_dosen']);
Route::post('/update_datadosen', [Dosen_Controller::class, 'update_datadosen']);