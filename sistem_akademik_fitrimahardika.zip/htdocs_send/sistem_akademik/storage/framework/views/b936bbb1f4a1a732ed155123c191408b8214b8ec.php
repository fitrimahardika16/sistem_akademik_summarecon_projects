

<?php $__env->startSection('content'); ?>
 <div id="wrapper">

            <!-- Navigation -->
               <?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- Navigation -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Forms Tambah Data Mata Kuliah</h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Forms Tambah Data Mata Kuliah
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <form role="form" action="/savematakuliah" method="post">
                                            	<?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label>Kode Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" name="kode_matakuliah" required>
                                                </div>
                                                 <div class="form-group">
                                                    <label>Nama Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Nama Mata Kuliah"
                                                    name="nama_matakuliah">
                                                </div>
                                                 <div class="form-group">
                                                    <label>SKS</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" name="sks">
                                                </div>
                                                <!-- <div class="form-group">
                                                    <label>Tanggal Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="date" name="tanggal">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Masuk</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="time" name="jam_masuk">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Keluar</label>
                                                    <input class="form-control" placeholder="time"
                                                     type="time" name="jam_keluar">
                                                </div> -->
                                               <!--  <div class="form-group">
                                                    <label>File input</label>
                                                    <input type="file">
                                                </div> -->
                                               <!--  <div class="form-group">
                                                    <label>Text area</label>
                                                    <textarea class="form-control" rows="3"></textarea>
                                                </div> -->
                                                <button type="submit" class="btn btn-default">Submit Button</button>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_akademik\resources\views/tambah_mata_kuliah.blade.php ENDPATH**/ ?>