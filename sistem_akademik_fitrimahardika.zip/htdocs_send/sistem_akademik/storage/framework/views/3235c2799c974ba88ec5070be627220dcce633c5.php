

<?php $__env->startSection('content'); ?>
 <div id="wrapper">

            <!-- Navigation -->
               <?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- Navigation -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Forms Tambah Data Jadwal Kuliah</h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Forms Tambah Data Jadwal Kuliah
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <form role="form" action="/saveJadwal" method="post">
                                            	<?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label>Nama Mahasiswa</label>
                                                   <select class="form-control" name="nim_mahasiswa">

                                                <?php $__currentLoopData = $data_mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option value="<?php echo e($value->nim_mahasiswa); ?>"> 

                                                        <?php echo e($value->nama_mahasiswa); ?> 

                                                    </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                                            </select>
                                                </div>
                                                 <div class="form-group">
                                                     <label>Nama Dosen</label>
                                                    <select class="form-control" name="id_dosen">

                                                <?php $__currentLoopData = $data_dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option value="<?php echo e($value->id_dosen); ?>"> 

                                                        <?php echo e($value->nama_dosen); ?> 

                                                    </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                                            </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mata Kuliah</label>
                                                    <select class="form-control" name="kode_matakuliah">

                                                <?php $__currentLoopData = $data_matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option value="<?php echo e($value->kode_matakuliah); ?>"> 

                                                        <?php echo e($value->nama_matakuliah); ?> 

                                                    </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                                            </select>
                                                </div>
                                              <div class="form-group">
                                                    <label>Tanggal Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="date" name="tanggal">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Masuk</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="time" name="jam_masuk">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Keluar</label>
                                                    <input class="form-control" placeholder="time"
                                                     type="time" name="jam_keluar">
                                                </div>
                                                <button type="submit" class="btn btn-default">Submit Button</button>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_akademik\resources\views/tambah_jadwal.blade.php ENDPATH**/ ?>