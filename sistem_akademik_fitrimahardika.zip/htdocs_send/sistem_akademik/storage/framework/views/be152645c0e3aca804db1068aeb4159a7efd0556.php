

<?php $__env->startSection('content'); ?>
 <div id="wrapper">

            <!-- Navigation -->
               <?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- Navigation -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Forms Tambah Data Mata Kuliah</h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Forms Tambah Data Mata Kuliah
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form action="/update_matakuliah" role="form" action="/savematakuliah" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label>Kode Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" name="kode_matakuliah" value="<?php echo e($p->kode_matakuliah); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label>Nama Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Nama Mata Kuliah"
                                                    name="nama_matakuliah" value="<?php echo e($p->nama_matakuliah); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label>SKS</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" name="sks"
                                                    value="<?php echo e($p->sks); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Tanggal Mata Kuliah</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="date" name="tanggal" value="<?php echo e($p->tanggal); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Masuk</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" type="time" name="jam_masuk" value="<?php echo e($p->jam_masuk); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Jam Keluar</label>
                                                    <input class="form-control" placeholder="time"
                                                     type="time" name="jam_keluar" value="<?php echo e($p->jam_keluar); ?>">
                                                </div>
                                                <input type="hidden" name="id" value="<?php echo e($p->id_matakuliah); ?>">
                                               <!--  <div class="form-group">
                                                    <label>File input</label>
                                                    <input type="file">
                                                </div> -->
                                               <!--  <div class="form-group">
                                                    <label>Text area</label>
                                                    <textarea class="form-control" rows="3"></textarea>
                                                </div> -->
                                                <button type="submit" class="btn btn-default">Submit Button</button>
                                            </form>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_akademik\resources\views/edit_mata_kuliah.blade.php ENDPATH**/ ?>