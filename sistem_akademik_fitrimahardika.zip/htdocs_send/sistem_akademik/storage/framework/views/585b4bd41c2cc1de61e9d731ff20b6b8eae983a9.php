

<?php $__env->startSection('content'); ?>
 <div id="wrapper">

            <!-- Navigation -->
               <?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- Navigation -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Forms Tambah Data Mahasiswa</h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Forms Tambah Data Mahasiswa
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form action="/update_mahasiswa" role="form" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label>Nim Mahasiswa</label>
                                                    <input class="form-control" placeholder="Kode Mata Kuliah" name="nim_mahasiswa" value="<?php echo e($p->nim_mahasiswa); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label>Nama Mahasiswa</label>
                                                    <input class="form-control" placeholder="Nama Mata Kuliah"
                                                    name="nama_mahasiswa" value="<?php echo e($p->nama_mahasiswa); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label>Jenis Kelamin</label>
                                                    <input class="form-control" placeholder="Nama Mata Kuliah"
                                                    name="jenis_kealmi" value="<?php echo e($p->jenis_kealmi); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label>Alamat Mahasiswa</label>
                                                    <input class="form-control" placeholder="Nama Mata Kuliah"
                                                    name="alamat_mahasiswa" value="<?php echo e($p->alamat_mahasiswa); ?>">
                                                </div>
                                                <input type="hidden" name="id" value="<?php echo e($p->id_mahasiswa); ?>">
                                               <!--  <div class="form-group">
                                                    <label>File input</label>
                                                    <input type="file">
                                                </div> -->
                                               <!--  <div class="form-group">
                                                    <label>Text area</label>
                                                    <textarea class="form-control" rows="3"></textarea>
                                                </div> -->
                                                <button type="submit" class="btn btn-default">Submit Button</button>
                                            </form>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_akademik\resources\views/edit_mahasiswa.blade.php ENDPATH**/ ?>