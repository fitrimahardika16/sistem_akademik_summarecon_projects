

<?php $__env->startSection('content'); ?>
 <div id="wrapper">

            <!-- Navigation -->
               <?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- Navigation -->
        <div id="page-wrapper">
           <div class="container-fluid">
                <div class="row">
                   <div class="col-lg-12">
                        <h1 class="page-header">Data Mahasiswa</h1>
                    </div>
                      <a class="btn btn-primary" href="/tambah_mahasiswa" role="button"> Tambah Data Mahasiswa</a>
                </div>
                <br>
                    <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Data Mahasiswa
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                   <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th> Nim Mahasiswa </th>
                                               <th>Nama Mahasiswa</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Alamat Mahasiswa</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo e($data->nim_mahasiswa); ?></td>
                                                <td><?php echo e($data->nama_mahasiswa); ?></td>
                                                <td><?php if($data->jenis_kealmi == 1): ?>
                                                    Laki-Laki
                                                <?php else: ?>
                                                    Perempuan
                                                <?php endif; ?></td>
                                                <td><?php echo e($data->alamat_mahasiswa); ?></td>

                                              <td>
                                              <a href="/edit_mahasiswa/<?php echo e($data->id_mahasiswa); ?>">Edit</a>|<a href="/delete_mahasiswa/<?php echo e($data->id_mahasiswa); ?>">Hapus</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                  <!--   <nav aria-label="...">
                                      <ul class="pagination">
                                        <li class="page-item disabled">
                                          <span class="page-link">Previous</span>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item active">
                                          <span class="page-link">
                                            2
                                            <span class="sr-only">(current)</span>
                                          </span>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item">
                                          <a class="page-link" href="#">Next</a>
                                        </li>
                                      </ul>
                                    </nav> -->
                                </div>
                                    <!-- /.table-responsive -->
                            </div>
                                <!-- /.panel-body -->
                        </div>
                            <!-- /.panel -->
                    </div>
                        <!-- /.col-lg-12 -->
                </div>
            </div>
                <!-- /.container-fluid -->
        </div>
            <!-- /#page-wrapper -->
    </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        DataTables JavaScript
        <script src="../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../js/dataTables/dataTables.bootstrap.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_akademik\resources\views/data_mahasiswa.blade.php ENDPATH**/ ?>